package com.zonaut.keycloak.extensions.resource;

public enum AuthCheckType {

    ANONYMOUS,
    AUTHENTICATED,
    AUTHENTICATED_WITH_ROLE,
    AUTHENTICATED_WITH_CLIENT,

}
